Optimizing fuses with F.Schmitt's PERL optimizer and using the
fuse model by Helmut Sennewald posted to yahoo in june-05.

This setup assumes these additional files to be located in the
schematic's working directory:

 optimizer.pl, simend_ltspice.pl, lib.zip, perl58.dll

plus tinyperl.exe accessible by a path.
See yahoo for these files.
