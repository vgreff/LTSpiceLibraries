Prof. H.W. Neuschwander
Fachhochschule Kaiserslautern
University op applied sciences
20.5.2009


All examples need as input a wavefile. I made a simple tone from an electronic organ.

All examples write the output-node to a wavefile named "ausgang.wav".

So you can hear the effect of time varying components with your waveplayer!


The theory of operation for time varying R L C is from:

Christophe BASSO
ON Semiconductor
14, rue Paul Mespl� - BP1112 - 31035 TOULOUSE Cedex 1 - France
33 (0)5 34 61 11 54
e-mail: christophe.basso@onsemi.com


