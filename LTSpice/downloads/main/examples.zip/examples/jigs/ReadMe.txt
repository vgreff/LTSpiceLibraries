
                         BEWARE!

The files in this directory are supplied to give an example
simulation for each Linear macromodel supplied.  These are
only test jigs to verify some basic functionality of the
macromodel and symbol -- not necessarily a recommended
circuit to use in production.  In some instances, the
circuits are in fact bad circuits designed to show that
the macromodel handles some fault condition as the physical
device would.

They are intended only to be a convenience to help to verify
that the model actually works.

                                  --Mike, Oct 4, 2006

