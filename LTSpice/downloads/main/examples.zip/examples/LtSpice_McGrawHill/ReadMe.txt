Dear Student, Instructor, or interested party:

Now that you have unzipped the download, you have a PowerPoint Presentation and approximately 50 circuit files.  Get started by viewing the PP presentation.  This will help you decide to download the free simulator from Linear Technology:

http://www.linear.com/designtools/software/

We at McGraw-Hill hope that you will find the PowerPoint presentation and the sample circuits useful.


Charles A. Schuler

P.S. This version is much improved thanks to feedback from reviewers such as Helmut Sennenwald.